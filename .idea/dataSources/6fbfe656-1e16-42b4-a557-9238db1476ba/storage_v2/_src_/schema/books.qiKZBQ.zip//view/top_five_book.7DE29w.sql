create view top_five_book as
select `books`.`book`.`title` AS `title`, `books`.`book`.`grade` AS `grade`, `books`.`users`.`nickname` AS `author`
from (`books`.`book`
         join `books`.`users` on ((`books`.`book`.`author` = `books`.`users`.`id`)))
order by `books`.`book`.`grade` desc;

