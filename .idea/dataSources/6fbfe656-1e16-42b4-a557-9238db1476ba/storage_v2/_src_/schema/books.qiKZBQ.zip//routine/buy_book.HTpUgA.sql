create
    definer = root@localhost procedure buy_book(IN book bigint, IN user bigint)
BEGIN
	START TRANSACTION;

	SET @book_price = (SELECT price FROM book WHERE id = book);

	UPDATE profile
		SET balance = balance - @book_price
	WHERE user_id = `user`;
	
	UPDATE profile
		SET balance = balance + (@book_price * 0.8)
	WHERE user_id = (SELECT author FROM book WHERE id = book);

	INSERT INTO user_library (user_id, book_id, payment) 
		VALUES(`user`, book, 1);

	COMMIT;
END;

