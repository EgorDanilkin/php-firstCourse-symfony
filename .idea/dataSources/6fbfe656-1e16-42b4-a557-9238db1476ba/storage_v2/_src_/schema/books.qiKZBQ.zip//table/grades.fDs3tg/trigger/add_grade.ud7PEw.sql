create definer = root@localhost trigger add_grade
    after insert
    on grades
    for each row
BEGIN
	UPDATE book
		SET grade = (SELECT AVG(grade) FROM grades WHERE book_id = NEW.book_id),		
			number_grades = number_grades + 1
	WHERE id = NEW.book_id;
END;

