create view top_author as
select `books`.`users`.`nickname` AS `author`, avg(`books`.`book`.`grade`) AS `grade`
from (`books`.`book`
         join `books`.`users` on ((`books`.`book`.`author` = `books`.`users`.`id`)))
group by `books`.`book`.`author`;

